void setup() {
  // put your setup code here, to run once:
  pinMode(9,OUTPUT);
  pinMode(7, INPUT_PULLUP);
Serial.begin(9600);
}

void loop() {
  // put your main code here, to run repeatedly:
int value=analogRead(0);
int brightness=map(value, 0, 1023, 0, 255);
int stare=digitalRead(7);
  if(stare==LOW){
    analogWrite(9,brightness);
    Serial.println("BUTTON PRESSED");
    delay(500);
  }
  else{
    analogWrite(9,LOW);
    Serial.println("BUTTON RELEASED");
    delay(500);
  }
  if(brightness==0||stare==HIGH){
    Serial.println("LED OFF");
    delay(200);
  }
  else if(brightness>0&&stare==LOW){
    Serial.println("LED ON");
    delay(200);
  }

Serial.println(value);
delay(50);
}
